-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2021 at 06:54 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `youmade`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `a_id` int(4) NOT NULL,
  `a_nm` varchar(100) NOT NULL,
  `a_pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`a_id`, `a_nm`, `a_pwd`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `c_id` int(4) NOT NULL,
  `c_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`) VALUES
(2, 'music'),
(3, 'Entertainment'),
(4, 'Film & Animation'),
(8, 'Education'),
(16, 'Comedy');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `c_id` int(4) NOT NULL,
  `c_nm` varchar(100) NOT NULL,
  `c_email` varchar(100) NOT NULL,
  `c_msg` text NOT NULL,
  `c_status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`c_id`, `c_nm`, `c_email`, `c_msg`, `c_status`) VALUES
(3, 'rahul', 'rahulpansuriya96@gmail.com', 'hii  i m rahul ', 1),
(5, 'aqwdqwdqw', 'harshchapla006@gmail.com', 'dqwdqdq', 1),
(6, 'Hitesh', 'hiteshchavda88888@gmail.com', 'jkkkl,l\r\nklm,.,\r\nkl,', 1),
(7, 'hijko', 'vipullll@gmail.com', 'hjj', 1);

-- --------------------------------------------------------

--
-- Table structure for table `posting`
--

CREATE TABLE `posting` (
  `p_id` int(4) NOT NULL,
  `p_c_id` int(100) NOT NULL,
  `p_s_id` int(100) NOT NULL,
  `p_title` varchar(100) NOT NULL,
  `p_dec` longtext NOT NULL,
  `p_video` text NOT NULL,
  `p_thumb` text NOT NULL,
  `p_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `p_status` int(1) NOT NULL DEFAULT 1,
  `p_duration` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posting`
--

INSERT INTO `posting` (`p_id`, `p_c_id`, `p_s_id`, `p_title`, `p_dec`, `p_video`, `p_thumb`, `p_time`, `p_status`, `p_duration`) VALUES
(160, 3, 11, '_Dishoom__John_Abraham', 'Dishoom John Abraham, Varun Dhawan Pritam,Raftaar,Shahid Mallya(360p)', 'videos/1615106969_Dishoom__John_Abraham,_Varun_Dhawan__Pritam,_Raftaar,_Shahid_Mallya(360p).mp4', 'thumb/1615106969_Dishoom__John_Abraham,_Varun_Dhawan__Pritam,_Raftaar,_Shahid_Mallya(360p).mp4.jpg', '2021-03-07 08:49:29', 1, '00:03:49'),
(165, 3, 12, 'Duji_Vaar_Pyar_Sunanya', 'Duji_Vaar_Pyar_Sunanya', 'videos/1617079906Duji_Vaar_Pyar__Sunanda_Sharma__Sukh-E__Jaani__Arvindr_K__Official_Video__Mad_4_Music(1080p).mp4', 'thumb/1617079906Duji_Vaar_Pyar__Sunanda_Sharma__Sukh-E__Jaani__Arvindr_K__Official_Video__Mad_4_Music(1080p).mp4.jpg', '2021-03-30 04:51:47', 1, '00:03:50'),
(198, 3, 11, 'Teeji seat(official video)', 'Teeji seat(official video)', 'videos/1619023565_Teeji_Seat_(Official_Video)_Aakansha___New_Punjabi_Songs_2021-Latest_Punjabi_Songs_2020_2021(1080p)[1].mp4', 'thumb/1619023565Screenshot_2021_0421_221403[1].png', '2021-04-21 16:46:06', 1, '00:02:57'),
(199, 3, 11, 'Kale_Je_Libaas_Di_|_KAKA_|_Official_Video', 'Kale_Je_Libaas_Di_|_KAKA_|_Official_Video', 'videos/1619024392Kale_Je_Libaas_Di___KAKA___Official_Video___Ginni_Kapoor___Latest_Punjabi___New_Punjabi_Songs_2021(1080p)[1].mp4', 'thumb/1619024392Screenshot_2021_0421_222230[1].png', '2021-04-21 16:59:53', 1, '00:04:36'),
(200, 3, 11, 'So_High Sidhu_Moose_Wala', 'So_High Sidhu_Moose_Wala', 'videos/1619024855So_High___Official_Music_Video___Sidhu_Moose_Wala_ft._BYG_BYRD___Humble_Music(720p)[1].mp4', 'thumb/1619024855Screenshot_2021_0421_223516[1].png', '2021-04-21 17:07:35', 1, '00:03:54'),
(201, 3, 11, '_Aashiq_Purana_', '_Aashiq_Purana_', 'videos/1619025314New_Punjabi_Songs_2021___KAKA___Aashiq_Purana___Anjali_Arora_Adaab_Kharoud_Latest_Punjabi_Gana_Surma(1080p)[1].mp4', 'thumb/1619025314Screenshot_2021_0421_224203[1].png', '2021-04-21 17:15:16', 1, '00:03:34'),
(202, 3, 11, 'Temporary_Pyar_|_KAKA_|_Darling', 'Temporary_Pyar_|_KAKA_|_Darling', 'videos/1619025584Temporary_Pyar___KAKA___Darling___Adaab_Kharoud___Anjali_Arora___New_Punjabi_Songs_2021_Latest_Song(720p)[1].mp4', 'thumb/1619025584Screenshot_2021_0421_224641[1].png', '2021-04-21 17:19:44', 1, '00:04:35'),
(203, 4, 12, '_Aithey_Aa__Bharat__Salman_Khan', '_Aithey_Aa__Bharat__Salman_Khan', 'videos/1619026307_Aithey_Aa__Bharat__Salman_Khan,Katrina_Kaif_Vishal_&_Shekhar_ft._Akasa,_Neeti,_Kamaal(360p).mp4', 'thumb/1619026307Screenshot 2021-04-21 230100.png', '2021-04-21 17:31:47', 1, '00:03:39'),
(204, 4, 12, '_Jass_Manak_(Official_Video)', '_Jass_Manak_(Official_Video)', 'videos/1619026572_Jass_Manak_(Official_Video)_Satti_Dhillon__Latest_Punjabi_Songs__GK_DIGITAL__Geet_MP3(360p).mp4', 'thumb/1619026572Screenshot 2021-04-21 230529.png', '2021-04-21 17:36:12', 1, '00:03:46'),
(205, 4, 12, 'Meherbani Lyrica -The_Shaukeens', 'Meherbani Lyrica -The_Shaukeens', 'videos/1619026828Meherbani_-_Lyrical_-_The_Shaukeens__Akshay_Kumar__Arko__Jubin_Nautiyal(360p).mp4', 'thumb/1619026828Screenshot 2021-04-21 230939.png', '2021-04-21 17:40:28', 1, '00:04:07'),
(206, 4, 12, 'Mile_Ho_Tum by neha kakkar', 'Mile_Ho_Tum by neha kakkar', 'videos/1619027043Mile_Ho_Tum_-_Reprise_Version__Neha_Kakkar__Tony_Kakkar__Fever(720p).mp4', 'thumb/1619027043Screenshot 2021-04-21 231326.png', '2021-04-21 17:44:03', 1, '00:04:00'),
(207, 4, 12, 'Aabaad_Barbaad  song (LUDO-MOVIE)', 'Aabaad_Barbaad  song (LUDO-MOVIE)', 'videos/1619027251_Aabaad_Barbaad__Abhishek_B,_Aditya_K,_Rajkummar_R,_Sanya_M,_Fatima_S__Arijit,_Pritam,Sandeep(1080p).mp4', 'thumb/1619027251Screenshot 2021-04-21 231645.png', '2021-04-21 17:47:32', 1, '00:03:25');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `r_id` int(11) NOT NULL,
  `r_s_id` int(11) NOT NULL,
  `r_p_id` int(11) NOT NULL,
  `r_name` varchar(255) NOT NULL,
  `r_comment` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `r_status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`r_id`, `r_s_id`, `r_p_id`, `r_name`, `r_comment`, `created_at`, `r_status`) VALUES
(50, 14, 146, 'vishal', 'how to Drive partition ?', '2020-11-19 08:28:32', 1),
(51, 11, 146, 'hitesh', 'this sowft ware is free awailable ?', '2020-11-19 08:29:48', 1),
(54, 11, 160, 'Hitesh', 'hello world', '2021-04-20 16:17:52', 1);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `s_id` int(4) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `s_email` varchar(100) NOT NULL,
  `s_pwd` varchar(100) NOT NULL,
  `s_gender` varchar(100) NOT NULL,
  `s_mno` varchar(10) NOT NULL,
  `s_image` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `s_status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`s_id`, `s_name`, `s_email`, `s_pwd`, `s_gender`, `s_mno`, `s_image`, `created_at`, `s_status`) VALUES
(11, 'Hitesh', 'hitesh77777@gmail.com', '12345678', 'Male', '9426620898', 'user_profile/mdidm_1618919545.jpeg', '2020-11-18 22:33:01', 1),
(12, 'rahul', 'rahul@gmail.com', '12345678', 'Male', '9016191311', 'user_profile/rahul.jpg', '2020-11-19 06:52:06', 1),
(13, 'vipul', 'vipul@gmail.com', '12345678', 'male', '6352613550', '', '2020-11-19 07:05:28', 1),
(14, 'vishal', 'vishal@gmail.com', '12345678', 'male', '9824212067', '', '2020-11-19 07:22:34', 1),
(29, 'mehul', 'mehul7878@gmail.com', '12345678', 'male', '9824212067', '', '2021-03-27 11:40:28', 1),
(31, 'laxmi', 'laxmi6767@gmail.com', '12345678', 'Male', '9016191311', '', '2021-03-27 12:01:16', 1),
(35, 'krunal', 'krunal@gmail.com', '12345678', 'Male', '3625362536', '', '2021-03-28 15:56:03', 1),
(36, 'krunal', 'krunal7878@gmail.com', '12345678', 'Male', '1122334455', 'user_profile/mdidm_1618922189.jpeg', '2021-04-20 12:36:29', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `posting`
--
ALTER TABLE `posting`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `a_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `c_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `c_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `posting`
--
ALTER TABLE `posting`
  MODIFY `p_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `s_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
