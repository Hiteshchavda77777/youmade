<?php include("include/header.php") ?>
<?php include("include/config.php") ?>
<?php

$res = mysqli_query($con, "select * from category");

if (isset($_GET['del'])) {
    $de = "delete from category where c_id='" . $_GET['del'] . "'";
    $exe_del = mysqli_query($con, $de); {
?>
        <script>
            window.onload = function() {
                alert("Category Delete sucessfully");
                window.location = "manage_category.php";
            }
        </script>
<?php
    }
}
?>
<div class="main-content-inner">

    <div class="card mb-3">
        <div class="card-header">
            <i class="fa fa-table">
            </i> Category Table
        </div>
        <div class="card-body">
            <div class="table-responsive data-tables datatable-primary">
                <form method="post" enctype="multipart/form-data" class="form">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr align="center">
                                <th>No</th>
                                <th>Category Name</th>
                                <th>Delete</th>
                                <th>Edit</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $co = 1;
                            while ($rec = mysqli_fetch_array($res)) {
                                $cls = ($co % 2 != 0) ? '' : 'class="odd"';
                            ?>
                                <tr align="center" '.$cls.'>
                                    <td><?php echo $co; ?></td>
                                    <td><?php echo $rec['c_name']; ?></td>
                                    <td><a href="manage_category.php?del=<?php echo $rec['c_id']; ?>"><i class="fa fa-close" style="color:red;font-size:20px;"></i></a></td>
                                    <td><a href="edit_category.php?edt=<?php echo $rec['c_id']; ?>"><i class="fa fa-edit" style="font-size:20px;"></i></a></td>
                                </tr>
                            <?php
                                $co++;
                            }

                            ?>
                        </tbody>
                    </table>
            </div>
            </form>
        </div>
    </div>
</div>

</div>
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2020. All right reserved.</p>
    </div>
</footer>
<!-- footer area end-->
</div>

<!-- page container area end -->
<!-- jquery latest version -->
<script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/metisMenu.min.js"></script>
<script src="assets/js/jquery.slimscroll.min.js"></script>
<script src="assets/js/jquery.slicknav.min.js"></script>

<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
<!-- others plugins -->
<script src="assets/js/plugins.js"></script>
<script src="assets/js/scripts.js"></script>
</body>

</html>