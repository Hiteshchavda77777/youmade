<?php include("include/header.php") ?>
<?php include("include/config.php") ?>
<?php

$res = mysqli_query($con, "SELECT category.*, signup.*, posting.* FROM `posting` JOIN `signup` ON posting.p_s_id = signup.s_id JOIN `category` ON posting.p_c_id=category.c_id");
if (isset($_GET['del'])) 
{
	$xyz = $_GET['del'];
	//$de = "delete review.*, posting.* from posting INNER JOIN review ON posting.p_id = review.r_p_id where posting.p_id = $xyz ";
			$de = "delete from posting where p_id = '$xyz' ";
			$dee= "delete from review where r_p_id = '$xyz' ";
	$exe_del =  mysqli_query($con, $de);  
	$exee_del =  mysqli_query($con, $dee);  
?>
        <script>
            window.onload = function() {
                alert("video deleted successfully");
                window.location = "manage_videos.php";
            }
        </script>
<?php
}
?>
<div class="main-content-inner">

    <div class="card mb-3">
        <div class="card-header">
            <i class="fa fa-table">
            </i> Manage Videos
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <form method="post">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead style=" background-color:#4336fb !important;">  
                            <tr align="center">
                                <th>No</th>
                                <th>Category Name</th>
                                <th>Posted by</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>video</th>
                                <th>Delete</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $co = 1;
                            while ($rec = mysqli_fetch_array($res)) 
							{
									$cls = ($co % 2 != 0) ? '' : 'class="odd"';
								?>
									<tr align="center" '.$cls.'>
										<td><?php echo $co; ?></td>
										<td><?php echo $rec['c_name']; ?></td>
										<td><?php echo $rec['s_name']; ?></td>
										<td style="max-width:100px !important;"><?php echo $rec['p_title']; ?></td>
										<td style="max-width:200px !important;"><?php echo $rec['p_dec']; ?></td>
										<td>
											<!--<?php echo $rec['p_time']; ?>-->
											<div class="agile-products">
												<video controls width="257" style="height:auto; min-height: 200px; max-height:200px; border: 1px solid gray;" >
													<source src="../<?php echo $rec['p_video']; ?>" type="video/mp4">
												</video>
												<div style=" width:auto; max-width: 200px !important; min-height:71px; max-height:71px; height:auto; font: 14px oblique !important; padding-left: 0px !important; margin:0px !important; background-color: white !important; text-align:center !important;">   
													<?php
													echo '<i class ="fa fa-clock-o"; style=" font-size:17px; color:red; " ></i> &nbsp; ';
													echo '<b style="color:black !important; background-color:lightblue;" class="badge badge-primary" >'; 
													echo $rec['p_duration']; 
													echo '</b>';
													echo '<br>';
													echo $rec['p_title']; 
													echo '<br>'; 
													echo $rec['p_time'];
													echo '<br>';
													
													echo '<b class="fa fa-user" style="color:blue;"></b> &nbsp; ';
													echo '<b style=" color:white; height:15px !important; " class="badge badge-dark">';  
													echo $rec['s_name']; 
													echo '</b>';
													?>
												</div>
											</div>
										</td>
										
										<td><a href="manage_videos.php?del=<?php echo $rec['p_id']; ?>"><i class="fa fa-close" style="color:red;font-size:20px;"></i></a></td>
									</tr>
								<?php
									$co++;
                            
							}
                            ?>
                        </tbody>
                    </table>
            </div>
            </form>
        </div>
    </div>
</div>
</div>
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2020. All right reserved.</p>
    </div>
</footer>
<!-- footer area end-->
</div>
<!-- page container area end -->
<!-- jquery latest version -->
<script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/metisMenu.min.js"></script>
<script src="assets/js/jquery.slimscroll.min.js"></script>
<script src="assets/js/jquery.slicknav.min.js"></script>

<!-- start chart js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
<!-- start highcharts js -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<!-- start zingchart js -->
<script src="https://cdn.zingchart.com/zingchart.min.js"></script>
<script>
    zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
</script>
<!-- all line chart activation -->
<script src="assets/js/line-chart.js"></script>
<!-- all pie chart -->
<script src="assets/js/pie-chart.js"></script>
<!-- others plugins -->
<script src="assets/js/plugins.js"></script>
<script src="assets/js/scripts.js"></script>
</body>

</html>