<?php include("include/header.php") ?>
<?php include("include/config.php") ?>
<?php


if (isset($_POST['insert'])) {
    $cnm = $_POST['category'];
	$a="select * from category where c_name = '$cnm' ";
	$b=mysqli_query($con,$a);
	$c=mysqli_fetch_assoc($b);
		
	if(empty($c))
	{
			$cnm1 = $_POST['category'];
			$ins = "INSERT INTO `category`(`c_name`)VALUES ('$cnm1')";
			$exe = mysqli_query($con, $ins);
			if ($exe) {
		?>
				<script>
					window.onload = function() {
						alert("insert Succesfully");
						window.location = "manage_category.php";
					}
				</script>
		<?php
			}
			
	/* for category start */							
	}else{ ?>
			<script>
			window.onload = function() {
			alert("this Category is already exist ");
			window.location = "add_category.php";
			}
			</script>
	<?php }
	/* for category END */
}
?>

<div class="col-12 mt-3">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title">Add Category</h4>
            <form method="POST" enctype="multipart/form-data" class="form">
                <div class="form-group col-md-6">
                    <label for="example-text-input" class="col-form-label">Enter Category</label>
                    <input class="form-control" type="text" id="name" name="category" required>
                </div>
                <button type="submit" class="btn btn-primary pr-4 pl-4" name="insert">Submit</button>
            </form>
        </div>
    </div>
</div>
</div>
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2020. All right reserved.</p>
    </div>
</footer>
<!-- footer area end-->
</div>
<!-- page container area end -->
<!-- jquery latest version -->
<script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/metisMenu.min.js"></script>
<script src="assets/js/jquery.slimscroll.min.js"></script>
<script src="assets/js/jquery.slicknav.min.js"></script>

<!-- others plugins -->
<script src="assets/js/plugins.js"></script>
<script src="assets/js/scripts.js"></script>
</body>

</html>