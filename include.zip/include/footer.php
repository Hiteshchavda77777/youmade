
<!-- footer -->
<div class="footer">
	<div class="container">
		<div class="footer-info w3-agileits-info">
			<div class="col-md-3 address-left agileinfo">
				<div class="footer-logo header-logo">
					<?php 
						echo '<a href="index.php"><img src="images/logo.png" style="width:200px; height:100px; "></a>';
					?>
				</div>
				<ul>
					<li><i class="fa fa-map-marker"></i><?php echo 'rajkot, gujrat-360005';?></li>
					<li><i class="fa fa-mobile"></i><?php echo '123-456-7890';?> </li>
					<li><i class="fa fa-phone"></i> <?php echo '123-456-7890';?> </li>
					<li><i class="fa fa-envelope-o"></i> <a href="index.php"><?php echo 'youmade@gmail.com';?></a></li>
				</ul>
			</div>
				<div class="col-md-8 address-right">
					<div class="col-md-4 footer-grids">

					</div>
					<div class="col-md-4 footer-grids" style="margin-top:100px;">
						<h3><?php echo 'you made';?></h3>
						<ul>

							<?php
							if (!isset($_SESSION['snm'])) {
							?>
							<?php 	echo '<li><a href="signup.php">Signup</a></li>'; ?>
							<?php 	echo '<li><a href="login.php">Login</a></li>'; ?>
							<?php
							}
							?>
							<?php echo '<li><a href="contact.php">Contact</a></li>'; ?>
						</ul>

					</div>
					<div class="clearfix"></div>
				</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- //footer -->
<div class="copy-right">
	<div class="container">
		<p><?php echo date('Y'); ?> <?php echo 'You Made . All rights reserved | Design by ::';?> <a href="index.php"><?php echo 'you made'; ?></a></p>
	</div>
</div>
<!-- menu js aim -->
<script src="js/jquery.menu-aim.js"> </script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
<!-- //menu js aim -->
<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/bootstrap.js"></script>
</body>

</html>